UPDATE announcements SET title='Промежуточная аттестация с 14 декабря'
WHERE title='Промежуточная аттестация — с 14 декабря';
