param([string]$PostgresBin, [string]$NodePath)
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path (Split-Path $PSScriptRoot)
if (!$PostgresBin -or !$NodePath) { throw 'Pass -PostgresBin and -NodePath. Binaries are reused, databases are always separate.' }
$runtime = @{ node = (Resolve-Path -LiteralPath $NodePath).Path; postgres_bin = (Resolve-Path -LiteralPath $PostgresBin).Path }
New-Item -ItemType Directory -Path (Join-Path $projectPath 'var\config'),(Join-Path $projectPath 'var\logs') -Force | Out-Null
$dataPath = Join-Path $projectPath 'var\postgres'
$envPath = Join-Path $projectPath 'var\config\application.env'
if (Test-Path -LiteralPath $envPath) { throw 'application.env already exists; refusing to replace local credentials.' }
if (Test-Path -LiteralPath $dataPath) { throw 'Database directory already exists; refusing to initialize over it.' }
$runtime | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $projectPath 'var\config\runtime.json') -Encoding utf8
$password = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(24))
New-Item -ItemType Directory -Path (Join-Path $projectPath 'var\config') -Force | Out-Null
$passwordPath = Join-Path $projectPath 'var\config\init-password.tmp'
try {
  [IO.File]::WriteAllText($passwordPath,$password)
  & (Join-Path $PostgresBin 'initdb.exe') -D $dataPath -U deka --pwfile=$passwordPath --auth=scram-sha-256 --encoding=UTF8 --locale=C
  if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL initialization failed' }
} finally { Remove-Item -LiteralPath $passwordPath -Force -ErrorAction SilentlyContinue }
& (Join-Path $PostgresBin 'pg_ctl.exe') -D $dataPath -l (Join-Path $projectPath 'var\logs\postgres.log') -o '-p 55438 -h 127.0.0.1' -w start
if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL did not start' }
$env:PGPASSWORD = $password
try {
  & (Join-Path $PostgresBin 'createdb.exe') -h 127.0.0.1 -p 55438 -U deka deka
  if ($LASTEXITCODE -ne 0) { throw 'Database creation failed' }
} finally { Remove-Item Env:\PGPASSWORD }
[IO.File]::WriteAllText($envPath,"DATABASE_URL=postgres://deka:${password}@127.0.0.1:55438/deka`nORIGIN=http://127.0.0.1:5180`nHOST=127.0.0.1`nPORT=5180`nDEMO_MODE=true`n")
Write-Host 'Created an isolated PostgreSQL database on 127.0.0.1:55438.'
