param([switch]$Dev,[ValidateSet('auto','cpu')][string]$Acceleration='auto')
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path (Split-Path $PSScriptRoot)
$applicationPath = Join-Path $projectPath 'apps\portal'
$configuration = Join-Path $projectPath 'var\config\application.env'
$runtime = Get-Content -LiteralPath (Join-Path $projectPath 'var\config\runtime.json') | ConvertFrom-Json
$nodePath = (Resolve-Path -LiteralPath $runtime.node).Path
$databasePath = Join-Path $projectPath 'var\postgres'
$logPath = Join-Path $projectPath 'var\logs'
$runPath = Join-Path $projectPath 'var\run'
New-Item -ItemType Directory -Path $logPath,$runPath -Force | Out-Null
$env:PATH = (Split-Path $nodePath) + ';' + $env:PATH
if (!$env:BODY_SIZE_LIMIT) { $env:BODY_SIZE_LIMIT = '1200000' }
& (Join-Path $PSScriptRoot 'start-assistant.ps1') -Acceleration $Acceleration
if (Test-Path -LiteralPath (Join-Path $databasePath 'PG_VERSION')) {
  $postgresCtl = Join-Path $runtime.postgres_bin 'pg_ctl.exe'
  & $postgresCtl -D $databasePath status *> $null
  if ($LASTEXITCODE -ne 0) {
    & $postgresCtl -D $databasePath -l (Join-Path $logPath 'postgres.log') -o '-p 55438 -h 127.0.0.1' -w start
    if ($LASTEXITCODE -ne 0) { throw 'Could not start PostgreSQL.' }
  }
}
$existing = Get-NetTCPConnection -LocalPort 5180 -State Listen -ErrorAction SilentlyContinue
if ($existing) {
  try { $health = Invoke-RestMethod 'http://127.0.0.1:5180/health' -TimeoutSec 3 } catch { $health = $null }
  if ($health.service -eq 'deka' -and $health.status -eq 'ok') { Write-Host 'Deka is already running: http://127.0.0.1:5180'; exit 0 }
  throw 'Port 5180 is in use.'
}
$previousLocation = Get-Location
try {
  Set-Location -LiteralPath $applicationPath
  if (!(Test-Path -LiteralPath 'node_modules')) {
    $npmCli = Join-Path (Split-Path $nodePath) 'node_modules\npm\bin\npm-cli.js'
    & $nodePath $npmCli ci
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
  }
  & $nodePath "--env-file=$configuration" tooling/database/migrate.mjs
  if ($LASTEXITCODE -ne 0) { throw 'Database migration failed.' }
  if (!$Dev) {
    & $nodePath "--env-file=$configuration" node_modules/vite/bin/vite.js build
    if ($LASTEXITCODE -ne 0) { throw 'Production build failed.' }
  }
  $arguments = if ($Dev) { @('"--env-file='+$configuration+'"','node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5180','--strictPort') } else { @('"--env-file='+$configuration+'"','.output/index.js') }
  $process = Start-Process -FilePath $nodePath -ArgumentList $arguments -WorkingDirectory $applicationPath -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $logPath 'app.log') -RedirectStandardError (Join-Path $logPath 'app-error.log')
  @{pid=$process.Id;started=$process.StartTime.ToUniversalTime().ToString('O')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $runPath 'app-process.json')
  for ($attempt=0;$attempt -lt 60;$attempt++) {
    try { $health = Invoke-RestMethod 'http://127.0.0.1:5180/health' -TimeoutSec 2; if ($health.status -eq 'ok') { Write-Host 'Deka is ready: http://127.0.0.1:5180'; exit 0 } } catch {}
    if ($process.HasExited) { throw 'Application exited. See var/logs/app-error.log.' }
    Start-Sleep -Milliseconds 250
  }
  throw 'Application did not become ready. See var/logs/app-error.log.'
} finally { Set-Location -LiteralPath $previousLocation }
