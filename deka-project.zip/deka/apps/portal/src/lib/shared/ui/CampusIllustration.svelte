<svg
  class="campus"
  viewBox="0 0 360 260"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  aria-hidden="true"
>
  <circle cx="201" cy="122" r="103" fill="#E0DCF9" />
  <circle cx="201" cy="122" r="127" stroke="#D9D4F3" stroke-dasharray="3 7" />
  <path d="m57 181 142-72 131 75-139 72z" fill="#C6BFEB" />
  <path d="m76 124 123-62 112 64-123 62z" fill="#FAF9FF" />
  <path d="m76 124 112 64v55L76 179z" fill="#EEEAFD" />
  <path d="m188 188 123-62v54l-123 63z" fill="#B1A7E5" />
  <path d="m61 116 139-70 126 73-139 70z" fill="#7566CE" />
  <path d="M61 116v11l126 73v-11z" fill="#6352BA" />
  <path d="m187 189 139-70v11l-139 70z" fill="#8F80D9" />
  <path d="m103 147 16 9v32l-16-9zm35 20 16 9v32l-16-9z" fill="#C0B5ED" />
  <path d="m213 192 16-8v30l-16 8zm33-17 16-8v30l-16 8zm33-17 16-8v30l-16 8z" fill="#F8F6FF" />
  <path d="m152 107 45-23 43 25-45 23z" fill="#B5A8EF" />
  <path d="m152 107 43 25v8l-43-25z" fill="#A698E5" />
  <path d="m195 132 45-23v8l-45 23z" fill="#D6CCFF" />
  <path d="m198 84-2-45" stroke="#7566CE" stroke-width="3" />
  <path d="m197 39 36 5-5 18-31-4z" fill="#FAF9FF" />
  <path d="M47 180v32m-12-12 12 7 12-6" stroke="#A69ACF" stroke-width="3" stroke-linecap="round" />
  <path d="M310 207v23m-9-9 9 5 10-6" stroke="#A69ACF" stroke-width="3" stroke-linecap="round" />
  <rect x="42" y="44" width="59" height="46" rx="12" transform="rotate(-8 42 44)" fill="white" />
  <path
    d="m59 61 22-3m-21 10 16-2m-15 9 20-3"
    stroke="#A295D5"
    stroke-width="3"
    stroke-linecap="round"
  />
  <circle cx="296" cy="67" r="24" fill="white" /><path
    d="m285 67 7 7 14-15"
    stroke="#7566CE"
    stroke-width="3"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>
