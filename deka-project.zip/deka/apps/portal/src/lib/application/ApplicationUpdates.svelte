<script lang="ts">
  import { onMount } from 'svelte';
  import { installation, type InstallEvent } from '#shared/installation.svelte.ts';
  let waiting: ServiceWorker | null = $state(null),
    dismissed = $state(false);
  onMount(() => {
    const prompt = (event: Event) => {
      event.preventDefault();
      installation.event = event as InstallEvent;
    };
    const installed = () => {
      installation.event = null;
      installation.installed = true;
    };
    window.addEventListener('beforeinstallprompt', prompt);
    window.addEventListener('appinstalled', installed);
    let registration: ServiceWorkerRegistration | undefined,
      worker: ServiceWorker | null = null,
      alive = true;
    const updated = () => {
      if (registration?.waiting) waiting = registration.waiting;
    };
    const changed = () => {
      if (worker?.state === 'installed' && navigator.serviceWorker.controller) updated();
    };
    const found = () => {
      worker = registration?.installing ?? null;
      worker?.addEventListener('statechange', changed);
    };
    if ('serviceWorker' in navigator)
      void navigator.serviceWorker.ready.then((value) => {
        if (!alive) return;
        registration = value;
        updated();
        registration.addEventListener('updatefound', found);
      });
    return () => {
      alive = false;
      window.removeEventListener('beforeinstallprompt', prompt);
      window.removeEventListener('appinstalled', installed);
      registration?.removeEventListener('updatefound', found);
      worker?.removeEventListener('statechange', changed);
    };
  });
  function applyUpdate() {
    if (!waiting) return;
    navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), {
      once: true
    });
    waiting.postMessage('APPLY_UPDATE');
  }
</script>

{#if waiting && !dismissed}<aside class="update" role="status">
    <span>Доступна новая версия Деки</span><button class="btn" onclick={applyUpdate}
      >Обновить</button
    ><button class="later" onclick={() => (dismissed = true)}>Позже</button>
  </aside>{/if}

<style>
  .update {
    position: fixed;
    z-index: 200;
    bottom: 24px;
    right: 24px;
    display: flex;
    align-items: center;
    gap: 15px;
    background: #fff;
    padding: 15px 20px;
    border: 1px solid #e0ddef;
    border-radius: 15px;
    box-shadow: 0 8px 30px #24253218;
    font-size: 13px;
    max-width: calc(100vw - 32px);
  }
  .later {
    color: #767080;
    background: transparent;
  }
  @media (max-width: 600px) {
    .update {
      right: 16px;
      bottom: 16px;
      flex-wrap: wrap;
    }
  }
</style>
