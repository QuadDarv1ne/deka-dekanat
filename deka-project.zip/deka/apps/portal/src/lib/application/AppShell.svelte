<script lang="ts">
  import { page } from '$app/state';
  import type { Snippet } from 'svelte';
  import type { ApplicationData } from './application.types';
  import AppSidebar from './AppSidebar.svelte';
  import AppHeader from './AppHeader.svelte';
  import { navigationFor } from './navigation';
  let { data, children }: { data: ApplicationData; children: Snippet } = $props();
  let menuOpen = $state(false),
    windowWidth = $state(1280);
  const current = $derived(
    navigationFor(data.user.role).find((n) => page.url.pathname.startsWith(n.href))?.name ??
      'Личный кабинет'
  );
</script>

<svelte:window
  bind:innerWidth={windowWidth}
  onkeydown={(event) => {
    if (event.key === 'Escape') menuOpen = false;
  }}
/>
<a class="skip" href="#main">Перейти к содержимому</a>
{#if menuOpen}<button class="overlay" aria-label="Закрыть меню" onclick={() => (menuOpen = false)}
  ></button>{/if}
<AppSidebar {data} open={menuOpen} mobile={windowWidth <= 800} onclose={() => (menuOpen = false)} />
<div class="workspace">
  <AppHeader {data} {current} open={menuOpen} ontoggle={() => (menuOpen = !menuOpen)} />
  <main class="content" id="main">{@render children()}</main>
  <footer class="page-footer">
    <span>Дека</span><span
      >Цифровой деканат
      <span class="footer-dot">·</span> 2026</span
    >
  </footer>
</div>

<style>
  .workspace {
    margin-left: 238px;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  .content {
    width: 100%;
    max-width: 1530px;
    padding: 32px 34px 25px;
    margin: 0 auto;
    flex: 1;
  }
  .page-footer {
    display: flex;
    justify-content: space-between;
    padding: 15px 34px 24px;
    font-size: 11px;
    color: #686b73;
    max-width: 1530px;
    width: 100%;
    margin: auto;
  }
  .footer-dot {
    margin: 0 8px;
  }
  .overlay {
    display: none;
  }
  @media (min-width: 1600px) {
    .workspace {
      margin-left: 258px;
    }
    .content {
      padding: 38px 42px;
    }
    .page-footer {
      padding-left: 42px;
      padding-right: 42px;
    }
  }
  @media (max-width: 1150px) {
    .workspace {
      margin-left: 210px;
    }
    .content {
      padding: 28px 24px;
    }
  }
  @media (max-width: 800px) {
    .workspace {
      margin-left: 0;
    }
    .overlay {
      display: block;
      position: fixed;
      inset: 0;
      background: #24203855;
      z-index: 35;
    }
    .content {
      padding: 24px 18px;
    }
    .page-footer {
      font-size: 10px;
      padding: 12px 18px 24px;
    }
  }
</style>
