<script lang="ts">
  import { page } from '$app/state';
  import Icon from '#shared/ui/Icon.svelte';
  import Brand from '#shared/ui/Brand.svelte';
  import { navigationFor } from './navigation';
  import type { ApplicationData } from './application.types';
  let {
    data,
    open,
    mobile,
    onclose
  }: { data: ApplicationData; open: boolean; mobile: boolean; onclose: () => void } = $props();
  const navigation = $derived(navigationFor(data.user.role));
</script>

<aside class:open class="sidebar" inert={mobile && !open}>
  <a href="/overview" class="brand" onclick={onclose}><Brand /></a>
  <div class="institution">
    <div class="institution-icon"><Icon name="building" size={18} /></div>
    <div><strong>Цифровой деканат</strong><span>Учебный портал</span></div>
  </div>
  <div class="nav-caption">Личный кабинет</div>
  <nav aria-label="Главная навигация">
    {#each navigation as item}
      <a
        href={item.href}
        class:active={page.url.pathname.startsWith(item.href)}
        aria-current={page.url.pathname.startsWith(item.href) ? 'page' : undefined}
        onclick={onclose}
      >
        <Icon name={item.icon} size={19} /><span>{item.name}</span>
        {#if item.href === '/notifications' && data.unread}<span class="nav-count"
            >{data.unread}</span
          >{/if}
      </a>
    {/each}
  </nav>
  <div class="sidebar-bottom">
    <div class="help-card">
      <span class="help-icon"><Icon name="help" size={20} /></span><strong>Есть вопрос?</strong>
      <p>Деканат поможет разобраться.</p>
      <a href="/announcements">Контакты и объявления <Icon name="up" size={14} /></a>
    </div>
    <a
      class="profile-link"
      class:active={page.url.pathname === '/profile'}
      href="/profile"
      onclick={onclose}><Icon name="settings" size={18} />Мой профиль</a
    >
    <form method="POST" action="/logout">
      <button class="profile-link"><Icon name="logout" size={18} />Выйти из аккаунта</button>
    </form>
    <span class="version">Дека · 2026</span>
  </div>
</aside>

<style>
  .sidebar {
    position: fixed;
    inset: 0 auto 0 0;
    width: 238px;
    background: white;
    border-right: 1px solid #e9ebf1;
    z-index: 40;
    display: flex;
    flex-direction: column;
    padding: 33px 18px 17px;
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: Manrope, sans-serif;
    font-weight: 800;
    letter-spacing: -0.05em;
    font-size: 32px;
    margin: 0 14px 33px;
    line-height: 1;
  }

  .institution {
    display: flex;
    gap: 11px;
    border: 1px solid #edf0f5;
    border-radius: 12px;
    padding: 12px;
    margin: 0 3px 33px;
    align-items: center;
  }
  .institution-icon {
    display: grid;
    place-items: center;
    width: 31px;
    height: 32px;
    border-radius: 8px;
    background: #f3f4f8;
    color: #686c7a;
  }
  .institution strong {
    font-size: 12px;
    display: block;
    font-weight: 500;
  }
  .institution span {
    font-size: 11px;
    color: #686c75;
    display: block;
    margin-top: 3px;
  }
  .nav-caption {
    text-transform: uppercase;
    color: #6b6d75;
    font-size: 11px;
    letter-spacing: 0.11em;
    padding-left: 17px;
    margin-bottom: 13px;
  }
  nav {
    display: grid;
    gap: 6px;
  }
  nav a {
    display: flex;
    gap: 12px;
    align-items: center;
    min-height: 47px;
    padding: 13px 16px;
    border-radius: 10px;
    color: #676c79;
    font-size: 13px;
    transition: background 0.15s;
  }
  nav a:hover {
    background: #f7f6fc;
  }
  nav a.active {
    color: #6255c5;
    background: #efedfc;
    font-weight: 500;
  }
  .nav-count {
    margin-left: auto;
    font-size: 12px;
    background: #e8e4fb;
    color: #6d60b3;
    padding: 1px 6px;
    border-radius: 5px;
  }
  .sidebar-bottom {
    margin-top: auto;
    padding-top: 30px;
  }
  .help-card {
    padding: 18px 14px;
    background: #f7f7fb;
    border-radius: 12px;
    position: relative;
    margin: 0 3px 18px;
  }
  .help-icon {
    position: absolute;
    top: 17px;
    right: 14px;
    color: #6b687a;
  }
  .help-card strong {
    font-size: 13px;
    font-weight: 500;
  }
  .help-card p {
    font-size: 12px;
    color: #6a6c77;
    margin-top: 5px;
  }
  .help-card a {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    color: #6d61a2;
    margin-top: 13px;
  }
  .profile-link {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    font-size: 13px;
    color: #686c79;
    padding: 11px 16px;
    background: transparent;
    border-radius: 9px;
    text-align: left;
  }
  .profile-link:hover,
  .profile-link.active {
    background: #f5f4fc;
    color: #6e60b8;
  }
  .version {
    display: block;
    color: #686b70;
    font-size: 11px;
    margin: 16px 17px 0;
  }
  @media (min-width: 1600px) {
    .sidebar {
      width: 258px;
      padding-left: 22px;
      padding-right: 22px;
    }
    nav a {
      font-size: 13px;
    }
    .institution strong {
      font-size: 13px;
    }
  }
  @media (max-height: 850px) and (min-width: 1001px) {
    .sidebar {
      padding-top: 24px;
    }
    .brand {
      margin-bottom: 23px;
    }
    .institution {
      margin-bottom: 23px;
    }
    .help-card {
      display: none;
    }
    .sidebar-bottom {
      padding-top: 18px;
    }
  }
  @media (max-width: 1150px) {
    .sidebar {
      width: 210px;
      padding-left: 12px;
      padding-right: 12px;
    }
  }
  @media (max-width: 800px) {
    .sidebar {
      transform: translateX(-100%);
      transition: transform 0.2s;
      width: 245px;
      padding: 26px 18px;
    }
    .sidebar.open {
      transform: translateX(0);
    }
    .help-card {
      display: block;
    }
  }
</style>
