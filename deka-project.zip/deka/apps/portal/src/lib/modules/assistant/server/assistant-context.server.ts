import type { User } from '#modules/auth/auth.types.ts';
import type { ChatSource } from '../assistant.types';
import { lessons, grades } from '#modules/academics/server/academic.repository.server.ts';
import { announcements } from '#modules/announcements/server/announcement.repository.server.ts';
import { listRequests } from '#modules/requests/server/request.repository.server.ts';

import { requestKinds, statusNames } from '#modules/requests/request.labels.ts';
import { fullDate, time } from '#shared/formatting.ts';

export async function assistantContext(user: User) {
  const [schedule, results, news, requests] = await Promise.all([
    lessons(user),
    user.role === 'student' ? grades(user) : Promise.resolve([]),
    announcements(user),
    user.role === 'student' ? listRequests(user) : Promise.resolve([])
  ]);
  const sources: ChatSource[] = [
    {
      id: 'help',
      title: 'Заявления',
      href: user.role === 'student' ? '/requests/new' : '/overview'
    }
  ];
  const context: Record<string, unknown> = {
    currentDate: fullDate(new Date().toISOString()),
    currentTimeMoscow: new Intl.DateTimeFormat('ru-RU', {
      timeZone: 'Europe/Moscow',
      dateStyle: 'full',
      timeStyle: 'long'
    }).format(new Date()),
    role: user.role,
    help: 'Справку об обучении, о стипендии или для налоговой можно запросить в разделе «Мои заявления». Выберите тип, укажите цель и отправьте. Статусы: новое, в работе, готово к выдаче, завершено. Новое заявление студент может отменить. Срок подготовки уточняется в деканате. Адрес, телефон, часы работы и сроки нельзя придумывать. Официальный документ требует подписи вуза.',
    scoring:
      '85–100 баллов: отлично (5), 70–84: хорошо (4), 55–69: удовлетворительно (3), ниже 55: требуется пересдача.'
  };
  if (schedule.length) {
    context.schedule = schedule
      .filter((l) => new Date(l.ends_at) > new Date())
      .slice(0, 6)
      .map((l) => ({
        subject: l.subject,
        date: fullDate(l.starts_at),
        start: time(l.starts_at),
        end: time(l.ends_at),
        room: l.room,
        teacher: l.teacher
      }));
    sources.push({ id: 'schedule', title: 'Расписание', href: '/schedule' });
  }
  if (results.length) {
    context.grades = results.slice(0, 12).map((g) => ({ subject: g.subject, points: g.points }));
    sources.push({ id: 'grades', title: 'Успеваемость', href: '/grades' });
  }
  if (requests.length) {
    context.requests = requests.slice(0, 6).map((r) => ({
      number: r.number,
      type: requestKinds[r.kind],
      status: statusNames[r.status],
      comment: r.staff_note
    }));
    sources.push({ id: 'requests', title: 'Мои заявления', href: '/requests' });
  }
  context.announcements = news.slice(0, 3).map((n) => ({ title: n.title, text: n.body }));
  if (news.length)
    sources.push({ id: 'announcements', title: 'Объявления', href: '/announcements' });
  return { text: JSON.stringify(context), sources };
}
