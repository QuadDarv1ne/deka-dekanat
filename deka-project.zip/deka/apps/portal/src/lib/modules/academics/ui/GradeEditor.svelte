<script lang="ts">
  import { enhance } from '$app/forms';
  import {
    assignmentKey,
    type TeachingAssignment,
    type AcademicStudent
  } from '../academic-management.types.ts';
  let {
    assignments,
    students
  }: { assignments: TeachingAssignment[]; students: AcademicStudent[] } = $props();
  let assignment = $state(''),
    pending = $state(false);
  const group = $derived(assignments.find((a) => assignmentKey(a) === assignment)?.group_id);
  const available = $derived(students.filter((s) => s.group_id === group));
</script>

<section class="panel">
  <div class="panel-head">
    <div>
      <h2>Внести результат</h2>
      <p>Текущий результат по дисциплине будет обновлён.</p>
    </div>
  </div>
  <form
    method="POST"
    action="?/grade"
    class="form-grid"
    use:enhance={() => {
      pending = true;
      return async ({ update }) => {
        await update();
        pending = false;
      };
    }}
  >
    <label
      >Дисциплина, группа и преподаватель<select name="assignment" required bind:value={assignment}
        ><option value="" disabled>Выберите дисциплину</option>{#each assignments as a}<option
            value={assignmentKey(a)}>{a.group_name} · {a.subject} · {a.teacher}</option
          >{/each}</select
      ></label
    >
    <div class="fields">
      <label
        >Студент<select name="student" required disabled={!group}
          >{#each available as s}<option value={s.id}>{s.full_name}</option>{/each}</select
        ></label
      ><label
        >Баллы<input
          name="points"
          type="number"
          min="0"
          max="100"
          step="1"
          required
          placeholder="0–100"
        /></label
      >
    </div>
    <div class="row wrap">
      <button class="btn" disabled={pending || !group}
        >{pending ? 'Сохраняем…' : 'Сохранить результат'}</button
      ><span class="muted small">Студент получит уведомление.</span>
    </div>
  </form>
</section>

<style>
  .fields {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 15px;
  }
  @media (max-width: 600px) {
    .fields {
      grid-template-columns: 1fr;
    }
  }
</style>
