export const previewAccounts = [
  { code: 'student', name: 'Стальцов Александр Николаевич', role: 'student', icon: 'cap' },
  { code: 'student2', name: 'Климкин Егор Владимирович', role: 'student', icon: 'cap' },
  { code: 'student3', name: 'Дуплей Максим Игоревич', role: 'student', icon: 'cap' },
  { code: 'dean', name: 'Сотрудник деканата', role: 'dean', icon: 'files' },
  { code: 'teacher', name: 'Преподаватель', role: 'teacher', icon: 'book' },
  { code: 'admin', name: 'Администратор', role: 'admin', icon: 'shield' }
] as const;
