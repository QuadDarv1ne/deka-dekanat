<script lang="ts">
  import { enhance } from '$app/forms';
  import Campus from '#shared/ui/CampusIllustration.svelte';
  import Icon from '#shared/ui/Icon.svelte';
  import Brand from '#shared/ui/Brand.svelte';
  type PageProps = {
    data: { demo: boolean; accounts: ReadonlyArray<(typeof import('../preview-accounts.ts').previewAccounts)[number]> };
    form?: { message?: string } | null;
  };
  let { data, form }: PageProps = $props();
  let pending = $state(false);
</script>

<svelte:head><title>Вход · Дека</title></svelte:head>
<div class="login-page">
  <section class="welcome">
    <a class="brand" href="/" aria-label="Дека"><Brand /></a>
    <div class="welcome-body">
      <span class="welcome-label">Цифровой деканат</span>
      <h1>Ваш личный кабинет</h1>
      <p>Расписание, оценки и обращения в деканат.</p>
      <Campus />
      <div class="welcome-bottom">
        <span><Icon name="check" size={15} />Расписание и оценки</span><span
          ><Icon name="check" size={15} />Заявления онлайн</span
        >
      </div>
    </div>
    <span class="copyright">Цифровой деканат · 2026</span>
  </section>
  <main class="login-main">
    <div class="login-form">
      <span class="pill violet"><Icon name="building" size={13} />Личный кабинет</span>
      <h2>Вход в Деку</h2>
      <p class="muted intro">Используйте университетскую почту.</p>
      {#if form?.message}<p class="form-error" role="alert">{form.message}</p>{/if}
      <form
        method="POST"
        use:enhance={() => {
          pending = true;
          return async ({ update }) => {
            await update();
            pending = false;
          };
        }}
        class="form-grid"
      >
        <label
          >Университетская почта<input
            name="email"
            type="email"
            autocomplete="username"
            placeholder="name@university.ru"
            required
            maxlength="254"
          /></label
        >
        <label
          >Пароль<input
            name="password"
            type="password"
            autocomplete="current-password"
            placeholder="Введите пароль"
            required
            maxlength="128"
          /></label
        >
        <button class="btn" disabled={pending}
          >{pending ? 'Входим…' : 'Войти в кабинет'}<Icon name="arrow" size={16} /></button
        >
      </form>
      {#if data.demo}<div class="demo">
          <div class="demo-heading"><span></span>Быстрый вход<span></span></div>
          <p>Студенты</p>
          <div class="demo-grid">
            {#each data.accounts as account}<form
                class:student-account={account.role === 'student'}
                method="POST"
                use:enhance
              >
                <input type="hidden" name="account" value={account.code} /><button
                  ><Icon name={account.icon} size={17} />{account.name}<Icon
                    name="up"
                    size={13}
                  /></button
                >
              </form>{/each}
          </div>
        </div>{/if}
      <div class="login-help">
        <Icon name="shield" size={16} /><span
          >Доступ предоставляется университетом.<br />Если не получается войти, обратитесь в
          деканат.</span
        >
      </div>
    </div>
  </main>
</div>

<style>
  .login-page {
    min-height: 100vh;
    display: grid;
    grid-template-columns: 1.06fr 1fr;
    background: #fff;
  }
  .welcome {
    background: #eeebfa;
    display: flex;
    flex-direction: column;
    padding: 46px 60px;
    min-height: 100vh;
    overflow: hidden;
  }
  .brand {
    font-family: Manrope, sans-serif;
    font-weight: 800;
    font-size: 38px;
    letter-spacing: -0.055em;
    align-self: flex-start;
  }

  .welcome-body {
    margin: auto 0;
    padding: 45px 0 24px;
    position: relative;
  }
  .welcome-label {
    font-size: 12px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #71688b;
  }
  h1 {
    font-size: 35px;
    line-height: 1.45;
    margin-top: 21px;
    color: #3b325c;
    letter-spacing: -0.045em;
  }
  .welcome-body > p {
    color: #706886;
    font-size: 13px;
    line-height: 1.9;
    margin-top: 20px;
  }
  .welcome-body :global(.campus) {
    display: block;
    width: min(360px, 80%);
    margin: 27px auto 23px;
  }
  .welcome-bottom {
    display: flex;
    gap: 32px;
    color: #71678e;
    font-size: 12px;
  }
  .welcome-bottom span {
    display: flex;
    gap: 7px;
    align-items: center;
  }
  .copyright {
    font-size: 12px;
    color: #706982;
    margin-top: auto;
  }
  .login-main {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 50px 40px;
  }
  .login-form {
    width: 100%;
    max-width: 350px;
  }
  .login-form h2 {
    font-size: 28px;
    margin-top: 25px;
  }
  .intro {
    font-size: 13px;
    margin-top: 10px;
    margin-bottom: 28px;
  }
  .login-form label {
    font-size: 13px;
  }
  .login-form input {
    font-size: 13px;
  }
  .login-form .btn {
    width: 100%;
    margin-top: 3px;
    justify-content: space-between;
  }
  .form-error {
    margin-bottom: 20px;
  }
  .demo {
    margin-top: 33px;
  }
  .demo-heading {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 11px;
    color: #686b71;
  }
  .demo-heading span {
    height: 1px;
    background: #eeeef4;
    flex: 1;
  }
  .demo > p {
    text-align: center;
    font-size: 11px;
    color: #686a70;
    margin: 8px 0 15px;
  }
  .demo-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 9px;
  }
  .student-account {
    grid-column: 1 / -1;
  }
  .demo-grid button {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 12px;
    font-size: 12px;
    color: #736882;
    border: 1px solid #eeedf5;
    border-radius: 9px;
    width: 100%;
    background: #faf9fd;
  }
  .demo-grid button:hover {
    border-color: #c6b9ef;
    background: #f3f0fb;
  }
  .demo-grid button :global(svg:last-child) {
    margin-left: auto;
    color: #706b7c;
  }
  .login-help {
    display: flex;
    align-items: flex-start;
    gap: 9px;
    font-size: 11px;
    color: #6b6d75;
    line-height: 1.8;
    margin-top: 30px;
  }
  .login-help :global(svg) {
    margin-top: 2px;
  }
  @media (max-width: 1050px) {
    .welcome {
      padding: 40px;
    }
    h1 {
      font-size: 29px;
    }
    .welcome-bottom {
      gap: 18px;
      font-size: 11px;
    }
  }
  @media (max-width: 800px) {
    .login-page {
      grid-template-columns: 1fr;
    }
    .welcome {
      min-height: 0;
      padding: 23px 28px;
    }
    .brand {
      font-size: 30px;
    }
    .welcome-body,
    .copyright {
      display: none;
    }
    .login-main {
      padding: 40px 24px 55px;
      align-items: flex-start;
    }
    .login-form h2 {
      font-size: 26px;
    }
  }
</style>
