export interface Announcement {
  id: string;
  title: string;
  body: string;
  tag: string;
  created_at: string;
}
