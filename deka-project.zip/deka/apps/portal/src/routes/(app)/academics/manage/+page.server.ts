import { fail, redirect, isHttpError } from '@sveltejs/kit';
import { requireRole } from '#modules/auth/server/auth.service.server.ts';
import {
  teachingAssignments,
  academicStudents,
  managedLessons
} from '#modules/academics/server/academic-management.repository.server.ts';
import {
  saveLesson,
  saveGrade,
  cancelLesson
} from '#modules/academics/server/academic-management.service.server.ts';
import { lessonValues, gradeValues } from '#modules/academics/server/academic-validation.server.ts';
import {
  prepareAcademicImport,
  importPreview,
  confirmAcademicImport
} from '#modules/academics/server/academic-import.service.server.ts';
import type { Actions, PageServerLoad } from './$types';
export const load = (async ({ locals, url }) => {
  const user = requireRole(locals.user, 'dean', 'teacher');
  const [assignments, students, lessons, draft] = await Promise.all([
    teachingAssignments(user),
    academicStudents(user),
    managedLessons(user),
    importPreview(user, url.searchParams.get('draft'))
  ]);
  return {
    assignments,
    students,
    lessons,
    draft,
    tab:
      user.role === 'teacher' || url.searchParams.get('tab') === 'grades'
        ? ('grades' as const)
        : ('schedule' as const),
    saved: url.searchParams.has('saved')
  };
}) satisfies PageServerLoad;
const recover = (cause: unknown) => {
  if (isHttpError(cause)) return fail(cause.status, { message: cause.body.message });
  throw cause;
};
export const actions = {
  lesson: async ({ locals, request }) => {
    try {
      await saveLesson(requireRole(locals.user, 'dean'), lessonValues(await request.formData()));
    } catch (cause) {
      return recover(cause);
    }
    redirect(303, '/academics/manage?tab=schedule&saved');
  },
  grade: async ({ locals, request }) => {
    try {
      await saveGrade(
        requireRole(locals.user, 'dean', 'teacher'),
        gradeValues(await request.formData())
      );
    } catch (cause) {
      return recover(cause);
    }
    redirect(303, '/academics/manage?tab=grades&saved');
  },
  cancel: async ({ locals, request }) => {
    const form = await request.formData();
    try {
      await cancelLesson(
        requireRole(locals.user, 'dean'),
        String(form.get('id') ?? ''),
        Number(form.get('version'))
      );
    } catch (cause) {
      return recover(cause);
    }
    redirect(303, '/academics/manage?tab=schedule&saved');
  },
  preview: async ({ locals, request }) => {
    const user = requireRole(locals.user, 'dean', 'teacher'),
      form = await request.formData(),
      kind = form.get('kind'),
      file = form.get('file');
    if (!['schedule', 'grades'].includes(String(kind)) || !(file instanceof File))
      return fail(400, { message: 'Выберите тип импорта и файл.' });
    let id: string;
    try {
      id = await prepareAcademicImport(user, kind as 'schedule' | 'grades', file);
    } catch (cause) {
      return recover(cause);
    }
    redirect(303, `/academics/manage?tab=${kind}&draft=${id}`);
  },
  confirm: async ({ locals, request }) => {
    const form = await request.formData();
    let kind: string;
    try {
      kind = await confirmAcademicImport(
        requireRole(locals.user, 'dean', 'teacher'),
        String(form.get('id') ?? '')
      );
    } catch (cause) {
      return recover(cause);
    }
    redirect(303, `/academics/manage?tab=${kind}&saved`);
  }
} satisfies Actions;
