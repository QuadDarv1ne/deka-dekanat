import { requireUser, requireRole } from '#modules/auth/server/auth.service.server.ts';
import type { PageServerLoad } from './$types';
import { getOverview } from '#modules/overview/server/overview.service.server.ts';
export const load = (async ({ locals }) =>
  getOverview(requireUser(locals.user))) satisfies PageServerLoad;
