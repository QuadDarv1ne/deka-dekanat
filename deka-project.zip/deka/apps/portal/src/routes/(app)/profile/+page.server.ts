import { requireUser } from '#modules/auth/server/auth.service.server.ts';
import type { PageServerLoad } from './$types';
export const load = (({ locals }) => ({
  profile: requireUser(locals.user)
})) satisfies PageServerLoad;
