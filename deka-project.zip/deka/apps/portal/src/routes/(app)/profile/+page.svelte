<script lang="ts">
  import ProfileView from '#modules/auth/ui/ProfileView.svelte';
  import type { PageProps } from './$types';
  let { data }: PageProps = $props();
</script>

<ProfileView {data} />
