import { requireUser } from '#modules/auth/server/auth.service.server.ts';
import { unreadCount } from '#modules/notifications/server/notification.repository.server.ts';
import type { LayoutServerLoad } from './$types';
import { redirect } from '@sveltejs/kit';
export const load = (async ({ locals, url }) => {
  if (!locals.user && url.pathname.startsWith('/student-card/verify/'))
    redirect(303, `/login?next=${encodeURIComponent(url.pathname)}`);
  const user = requireUser(locals.user);
  return { user, unread: await unreadCount(user.id) };
}) satisfies LayoutServerLoad;
