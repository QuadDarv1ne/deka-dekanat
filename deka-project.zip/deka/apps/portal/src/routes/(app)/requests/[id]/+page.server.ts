import { fail, isHttpError } from '@sveltejs/kit';
import { requireRole } from '#modules/auth/server/auth.service.server.ts';
import { getRequest, requestEvents } from '#modules/requests/server/request.repository.server.ts';
import { transitionRequest } from '#modules/requests/server/request.service.server.ts';
import type { RequestStatus } from '#modules/requests/request.types.ts';
import type { Actions, PageServerLoad } from './$types';
export const load = (async ({ locals, params }) => {
  const user = requireRole(locals.user, 'student', 'dean');
  const request = await getRequest(user, params.id);
  return { request, events: await requestEvents(request.id) };
}) satisfies PageServerLoad;
export const actions = {
  default: async ({ locals, request, params }) => {
    const user = requireRole(locals.user, 'student', 'dean');
    const form = await request.formData();
    try {
      await transitionRequest(
        user,
        params.id,
        String(form.get('status')) as RequestStatus,
        Number(form.get('version')),
        String(form.get('note') ?? '').trim()
      );
    } catch (err) {
      if (isHttpError(err)) return fail(err.status, { message: err.body.message });
      throw err;
    }
    return { message: 'Статус заявления обновлён.', success: true };
  }
} satisfies Actions;
