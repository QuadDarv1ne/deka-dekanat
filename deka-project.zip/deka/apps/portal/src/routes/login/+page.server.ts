import { fail, redirect } from '@sveltejs/kit';
import { signIn, quickSignIn } from '#modules/auth/server/auth.service.server.ts';
import { previewAccounts } from '#modules/auth/preview-accounts.ts';
import type { Actions, PageServerLoad } from './$types';

export const load = (({ locals, url }) => {
  if (locals.user) redirect(303, '/overview');
  const demo = process.env.DEMO_MODE === 'true' && ['127.0.0.1', 'localhost'].includes(url.hostname);
  return {
    demo,
    accounts: demo ? previewAccounts : []
  };
}) satisfies PageServerLoad;
export const actions = {
  default: async ({ request, cookies, url }) => {
    const form = await request.formData();
    const destination = url.searchParams.get('next');
    const next =
      destination && /^\/student-card\/verify\/[0-9a-f-]{36}$/.test(destination)
        ? destination
        : '/overview';
    if (form.has('account')) {
      if (!(await quickSignIn(String(form.get('account')), cookies, url)))
        return fail(403, { message: 'Быстрый вход недоступен.' });
      redirect(303, next);
    }
    const email = String(form.get('email') ?? '')
      .trim()
      .toLowerCase();
    const password = String(form.get('password') ?? '');
    if (!email || email.length > 254 || password.length < 1 || password.length > 128)
      return fail(400, { message: 'Введите почту и пароль.' });
    if (!(await signIn(email, password, cookies, url.protocol === 'https:')))
      return fail(400, {
        message: 'Не удалось войти. Проверьте почту и пароль или повторите попытку через 15 минут.'
      });
    redirect(303, next);
  }
} satisfies Actions;
