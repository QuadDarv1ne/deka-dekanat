import pg from 'pg';
import { previewAccounts } from '../../src/lib/modules/auth/preview-accounts.ts';
const connection = new URL(process.env.DATABASE_URL);
if (process.env.DEMO_MODE !== 'true' || !['127.0.0.1', 'localhost'].includes(connection.hostname))
  throw new Error('Only an explicitly local presentation database can be updated.');
const db = new pg.Client({ connectionString: connection.href });
await db.connect();
try {
  await db.query('BEGIN');
  for (const account of previewAccounts.filter((a) => a.role === 'student')) {
    const updated = await db.query(
      "UPDATE users SET full_name=$1 WHERE email=$2 AND role='student'",
      [account.name, `${account.code}@deka.test`]
    );
    if (updated.rowCount !== 1)
      throw new Error(`Student account missing: ${account.code}. No changes saved.`);
  }
  await db.query('COMMIT');
  console.log(
    'Updated three presentation student profiles. Passwords and academic records retained.'
  );
} catch (error) {
  await db.query('ROLLBACK');
  throw error;
} finally {
  await db.end();
}
